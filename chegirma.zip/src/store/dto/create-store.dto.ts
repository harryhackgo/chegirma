export class CreateStoreDto {
  name: string;
  location: string;
  phone: string;
  ownerId: number;
  StoreSocialLinkId: number;
  since: number;
  districtId: number;
  regionId: number;
}
