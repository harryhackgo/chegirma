export const BOT_NAME = "Chegirma bot";
