export class Favorite {}
