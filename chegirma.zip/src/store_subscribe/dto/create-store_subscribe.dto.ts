export class CreateStoreSubscribeDto {}
