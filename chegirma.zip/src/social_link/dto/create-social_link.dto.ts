export class CreateSocialLinkDto {
  name: string;
  icon?: string;
  storeSocialLinkId: number;
}
