export class CreateStoreSocialLinkDto {
  url: string;
  description: string;
}
