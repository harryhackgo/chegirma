export class Photo {}
