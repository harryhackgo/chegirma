export class CreateDistrictDto {
  name: string;
  regionId: number;
}
